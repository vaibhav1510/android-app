package com.servicedeskmanager.servicedesk.util;

/**
 * Created by DMX-I-LT-41 on 2/27/2017.
 */

public class SDUserDeatilsResponse {
    private Object profile;


    public Object getProfile() {
        return profile;
    }

    public void setProfile(Object profile) {
        this.profile = profile;
    }
}
