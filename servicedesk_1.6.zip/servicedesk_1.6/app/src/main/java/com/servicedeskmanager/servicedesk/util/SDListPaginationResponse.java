package com.servicedeskmanager.servicedesk.util;

/**
 * Created by DMX-I-LT-41 on 2/19/2017.
 */

public class SDListPaginationResponse {

    private Object[] results;

    public Object[] getResults() {
        return results;
    }

    public void setResults(Object[] results) {
        this.results = results;
    }
}
