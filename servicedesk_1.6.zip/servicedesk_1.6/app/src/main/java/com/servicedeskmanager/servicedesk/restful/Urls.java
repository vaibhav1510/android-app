package com.servicedeskmanager.servicedesk.restful;

public class Urls {

    public static String getUrl(String baseUrl,String url){

        return baseUrl+"/"+url;

    }
}
