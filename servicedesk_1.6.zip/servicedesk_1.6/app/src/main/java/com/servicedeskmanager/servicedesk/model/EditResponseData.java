package com.servicedeskmanager.servicedesk.model;

/**
 * Created by Admin-PC on 2/21/2017.
 */

public class EditResponseData {
    private EditIncidentModel editIncident;

    public EditIncidentModel getEditIncident() {
            return editIncident;
        }

    public void setEditIncident(EditIncidentModel editIncidentModels) {
            this.editIncident= editIncident;
        }
    }