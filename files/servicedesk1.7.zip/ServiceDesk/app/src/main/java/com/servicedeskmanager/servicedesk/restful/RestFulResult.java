package com.servicedeskmanager.servicedesk.restful;

public interface RestFulResult {
    public void onResfulResponse(String result, String responseFor);
}

