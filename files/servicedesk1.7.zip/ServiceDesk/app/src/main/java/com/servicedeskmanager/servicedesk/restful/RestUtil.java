package com.servicedeskmanager.servicedesk.restful;

public class RestUtil {

//public static ClientConfig getClientConfig(){
//    HttpAuthenticationFeature feature = HttpAuthenticationFeature.basicBuilder()
//            .nonPreemptive()
//            .credentials("java121", "abcd&^%3H908$#@")
//            .build();
//
//    ClientConfig clientConfig = new ClientConfig();
//    clientConfig.register(feature) ;
//    return clientConfig;
//}
}
