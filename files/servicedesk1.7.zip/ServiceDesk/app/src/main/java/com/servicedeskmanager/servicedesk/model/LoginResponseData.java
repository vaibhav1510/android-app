package com.servicedeskmanager.servicedesk.model;

public class LoginResponseData {
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    private String token;




}
