recyclerviewdemo
================

Sample project of my blog Grokking Android. Sample for this post: http://www.grokkingandroid.com/first-glance-androids-recyclerview/
