package com.grokkingandroid.samplesapp.samples.recyclerviewdemo;

public interface Constants {

    String KEY_ID = "keyId";

    String NAME_INNER_CONTAINER = "innerContainer";

}
